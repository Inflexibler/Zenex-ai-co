import { Octokit } from '@octokit/rest';

const octokit = new Octokit({
  auth: process.env.GITHUB_TOKEN,
});

// ✅ FIXED: Single source of truth for repo config
const OWNER = process.env.GITHUB_OWNER || 'Inflexibler';
const REPO = process.env.GITHUB_REPO || 'Zenex-users-data-1';
const CDN_BASE = 'https://cdn.jsdelivr.net/gh';

export interface GitHubFile {
  path: string;
  content: string;
  sha?: string;
}

export class GitHubClient {
  async createOrUpdateFile(
    userId: string,
    projectId: string,
    filename: string,
    content: string
  ): Promise<{ url: string; sha: string }> {
    try {
      const path = `users/${userId}/${projectId}/${filename}`;

      let sha: string | undefined;
      
      try {
        const existing = await octokit.repos.getContent({
          owner: OWNER,
          repo: REPO,
          path,
        });

        if ('sha' in existing.data) {
          sha = existing.data.sha;
        }
      } catch {
        // File doesn't exist yet, that's fine
      }

      const response = await octokit.repos.createOrUpdateFileContents({
        owner: OWNER,
        repo: REPO,
        path,
        message: `Update ${filename} for project ${projectId}`,
        content: Buffer.from(content).toString('base64'),
        ...(sha && { sha }),
      });

      // Purge CDN cache
      await this.purgeJSDelivr(path);

      return {
        url: `${CDN_BASE}/${OWNER}/${REPO}@main/${path}`,
        sha: response.data.content?.sha || '',
      };
    } catch (error) {
      console.error('Error creating/updating file:', error);
      throw error;
    }
  }

  async getFileContent(
    userId: string, 
    projectId: string, 
    filename: string
  ): Promise<string> {
    try {
      const path = `users/${userId}/${projectId}/${filename}`;

      const response = await octokit.repos.getContent({
        owner: OWNER,
        repo: REPO,
        path,
      });

      if (Array.isArray(response.data)) {
        throw new Error('Expected file, got directory');
      }

      if (!('content' in response.data)) {
        throw new Error('No content in response');
      }

      return Buffer.from(response.data.content, 'base64').toString('utf-8');
    } catch (error) {
      console.error('Error getting file content:', error);
      throw error;
    }
  }

  async deleteFile(
    userId: string,
    projectId: string,
    filename: string
  ): Promise<void> {
    try {
      const path = `users/${userId}/${projectId}/${filename}`;

      const existing = await octokit.repos.getContent({
        owner: OWNER,
        repo: REPO,
        path,
      });

      if (Array.isArray(existing.data)) {
        throw new Error('Expected file, got directory');
      }

      await octokit.repos.deleteFile({
        owner: OWNER,
        repo: REPO,
        path,
        message: `Delete ${filename} for project ${projectId}`,
        sha: existing.data.sha,
      });

      await this.purgeJSDelivr(path);
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  }

  async listProjectFiles(userId: string, projectId: string): Promise<string[]> {
    try {
      const path = `users/${userId}/${projectId}`;

      const response = await octokit.repos.getContent({
        owner: OWNER,
        repo: REPO,
        path,
      });

      if (!Array.isArray(response.data)) {
        return [];
      }

      return response.data
        .filter(item => item.type === 'file')
        .map(item => item.name);
    } catch (error) {
      if ((error as any).status === 404) {
        return []; // Directory doesn't exist yet
      }
      console.error('Error listing project files:', error);
      return [];
    }
  }

  async purgeJSDelivr(path: string): Promise<void> {
    try {
      const url = `https://purge.jsdelivr.net/gh/${OWNER}/${REPO}@main/${path}`;
      const response = await fetch(url, { method: 'POST' });

      if (!response.ok) {
        console.warn(`JSDelivr purge warning: ${response.status}`);
      }
    } catch (error) {
      console.error('Error purging JSDelivr cache:', error);
      // Don't throw - cache purge is not critical
    }
  }

  getPublicUrl(userId: string, projectId: string, filename: string): string {
    return `${CDN_BASE}/${OWNER}/${REPO}@main/users/${userId}/${projectId}/${filename}`;
  }

  getPreviewUrl(userId: string, projectId: string): string {
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://zenex.app';
    return `${appUrl}/preview/${userId}/${projectId}`;
  }
}

export const githubClient = new GitHubClient();
