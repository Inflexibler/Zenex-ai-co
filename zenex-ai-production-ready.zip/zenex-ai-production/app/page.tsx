import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-6">
            ZENEX AI
          </h1>
          <p className="text-2xl text-gray-700 mb-4">
            Build Professional Websites with AI in Minutes
          </p>
          <p className="text-lg text-gray-600 mb-12">
            Ghost serving architecture • Zero DB hits for visitors • AI-powered design
          </p>
          
          <div className="flex gap-4 justify-center mb-16">
            <Link 
              href="/dashboard"
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-semibold hover:opacity-90 transition"
            >
              Get Started Free
            </Link>
            <Link 
              href="/pricing"
              className="px-8 py-4 bg-white text-gray-800 rounded-lg font-semibold border-2 border-gray-300 hover:border-purple-600 transition"
            >
              View Pricing
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-xl font-bold mb-2">Lightning Fast</h3>
              <p className="text-gray-600">
                CDN-powered serving. Zero database queries for public visitors.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="text-4xl mb-4">🤖</div>
              <h3 className="text-xl font-bold mb-2">AI-Powered</h3>
              <p className="text-gray-600">
                Dual AI architecture. Claude for planning, Groq for speed.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="text-4xl mb-4">🔒</div>
              <h3 className="text-xl font-bold mb-2">Production-Ready</h3>
              <p className="text-gray-600">
                Enterprise security. Firewall-protected AI. Battle-tested infrastructure.
              </p>
            </div>
          </div>

          <div className="mt-16 p-8 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold mb-6">How It Works</h2>
            <div className="grid md:grid-cols-4 gap-6 text-left">
              <div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center text-purple-600 font-bold text-xl mb-4">1</div>
                <h4 className="font-bold mb-2">Describe Your Vision</h4>
                <p className="text-sm text-gray-600">Tell our AI what kind of website you need</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 font-bold text-xl mb-4">2</div>
                <h4 className="font-bold mb-2">AI Generates Design</h4>
                <p className="text-sm text-gray-600">Claude plans, Groq builds in seconds</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center text-green-600 font-bold text-xl mb-4">3</div>
                <h4 className="font-bold mb-2">Edit & Customize</h4>
                <p className="text-sm text-gray-600">Use our editor or ask AI to modify</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center text-orange-600 font-bold text-xl mb-4">4</div>
                <h4 className="font-bold mb-2">Deploy Instantly</h4>
                <p className="text-sm text-gray-600">Goes live on global CDN in seconds</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="border-t border-gray-200 mt-16 py-8">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© 2024 ZENEX AI. Built with ❤️ and AI.</p>
        </div>
      </footer>
    </div>
  );
}
